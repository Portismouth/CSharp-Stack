function generate(){
    $(document).ready(function () {
        $.get("generate", function(data){
            $(".passcode").text(data);
        });
        var counter = parseInt($(".count").text());
        $(".count").text(counter+1);
    });
}