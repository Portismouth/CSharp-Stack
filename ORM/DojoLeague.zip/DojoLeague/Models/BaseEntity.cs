using System.ComponentModel.DataAnnotations;

namespace DojoLeague.Models
{
    public abstract class BaseEntity {}
}