using System.ComponentModel.DataAnnotations;

namespace LoginReg2.Models
{
    public abstract class BaseEntity { }
}