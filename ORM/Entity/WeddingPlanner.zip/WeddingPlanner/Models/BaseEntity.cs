using System.ComponentModel.DataAnnotations;

namespace WeddingPlanner.Models
{
    public abstract class BaseEntity { }
}