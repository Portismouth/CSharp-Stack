using System.ComponentModel.DataAnnotations;

namespace ecommerce.Models
{
    public abstract class BaseEntity { }
}